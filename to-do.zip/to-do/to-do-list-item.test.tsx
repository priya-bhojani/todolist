import { beforeEach, describe } from "@jest/globals";
import React from "react";

import { TodoListItem } from "~src/to-do/to-do-list-item";
import { Todo } from "~src/to-do/toggleComplete";
import { render, screen } from "~test/helper/test-utils";

const mockToggleComplete = jest.fn();

const todo: Todo = {
  text: "dummy to do item 1",
  complete: true,
};
describe("To Do List Item", () => {
  beforeEach(() => {
    jest.resetAllMocks();
    render(
      <>
        <TodoListItem
          key={todo.text}
          todo={todo}
          toggleComplete={mockToggleComplete}
        />
      </>
    );
  });

  it("should render to do item checkbox", () => {
    const checkBoxForToDoItem = screen.getByRole("checkbox", {
      name: todo.text,
    });
    expect(checkBoxForToDoItem).toBeInTheDocument();
  });

  it("should render to do item text", () => {
    const toDoItem = screen.getByText(todo.text);
    expect(toDoItem).toBeInTheDocument();
  });
});

import React from "react";

import { ToDoComponent } from "~src/to-do/to-do";
export const App = () => {
  return <ToDoComponent />;
};

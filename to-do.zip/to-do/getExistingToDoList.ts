import { Todo } from "~src/to-do/toggleComplete";

export const getExistingToDos: Array<Todo> = [
  {
    text: "Prepare the assignment",
    complete: true,
  },
  {
    text: "Win the hearts!",
    complete: true,
  },
  {
    text: "Discuss the approach",
    complete: false,
  },
];
